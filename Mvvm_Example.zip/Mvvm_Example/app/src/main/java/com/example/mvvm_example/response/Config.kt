package com.example.mvvm_example.response

data class Config(
    var app: Int,
    var message: Int
)