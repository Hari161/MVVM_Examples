package com.example.mvvm_example.response

data class Data(
    var avilableMargin: AvilableMargin,
    var funds: Funds,
    var holdings: Holdings,
    var totalMargin: TotalMargin,
    var usedMargin: UsedMargin
)