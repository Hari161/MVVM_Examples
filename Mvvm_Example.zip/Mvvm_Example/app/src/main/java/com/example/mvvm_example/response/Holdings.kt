package com.example.mvvm_example.response

data class Holdings(
    var isDisp: String,
    var name: String,
    var value: String
)