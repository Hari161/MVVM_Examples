package com.example.mvvm_example.response

data class PostDataResponse(
    var config: Config,
    var echo: Echo,
    var response: Response
)