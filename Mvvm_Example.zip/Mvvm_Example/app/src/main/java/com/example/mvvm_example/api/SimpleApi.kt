package com.example.mvvm_example.api


import com.example.mvvm_example.request.PostDataReqst
import com.example.mvvm_example.response.PostDataResponse
import retrofit2.Response
import retrofit2.http.*

interface SimpleApi {

    @POST("Funds/Limit/1.0.1")
    suspend fun setRequest(
        @Body reqst : PostDataReqst
    ): Response<PostDataResponse>

}