package com.example.mvvm_example.request

data class Data(
    var grpID: String,
    var sessionID: String,
    var type: String,
    var usrCode: String,
    var usrID: String
)