package com.example.mvvm_example.response

data class AvilableMargin(
    var isDisp: String,
    var name: String,
    var value: String
)