package com.example.mvvm_example.request

data class PostDataReqst(
    var echo: Echo,
    var request: Request
)