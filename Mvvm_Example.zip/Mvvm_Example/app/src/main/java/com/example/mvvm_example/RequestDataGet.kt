package com.example.mvvm_example

class RequestDataGet {
    companion object GetValue {
        val SpinnerItem: String = "All Segments"
        val appId: String = "0cae918bfdfb10db2869fd86858d962a"
        val grpId: String = "ANGEL"
        val sessionId: String ="eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2NDA0Njg5ODgsImlhdCI6MTY0MDQzMjk4OCwib21uZW1hbmFnZXJpZCI6MSwic3ViIjoiSDg4ODg5In0.MMbek1RLN17vLE7RIZZULXEtp7iYRpb-D40OR4Ck1phlpLmKcz5E6xELMpiOXDfff46TnIBkEdFxDJxP8MZEpQ"
        val type: String = "All Segments"
        val usrCode: String = ""
        val usrID: String = "H88889"
        val formFactor: String = "M"
        val futures: String = "0"
        val response_format: String = "json"
    }
}