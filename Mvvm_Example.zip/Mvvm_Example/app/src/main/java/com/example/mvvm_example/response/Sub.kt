package com.example.mvvm_example.response

data class Sub(
    var isDisp: String,
    var name: String,
    var value: String
)