package com.example.mvvm_example.response

data class Echo(
    var SpinnerItem: String
)