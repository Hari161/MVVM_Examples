package com.example.mvvm_example.request

data class Echo(
    var SpinnerItem: String
)